require('dotenv').config();
const express = require('express');
const cors = require('cors');
const stockRoutes = require('./routes/stocks');
const correlationRoutes = require('./routes/correlation');
const errorHandler = require('./middleware/errorHandler');
const limiter = require('./middleware/rateLimiter');

const app = express();

app.use(cors());
app.use(express.json());
app.use(limiter); 

app.use('/stocks', stockRoutes);
app.use('/stockcorrelation', correlationRoutes);

app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date() });
});

app.use((req, res) => {
  res.status(404).json({ error: 'Endpoint not found' });
});

app.use(errorHandler);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});