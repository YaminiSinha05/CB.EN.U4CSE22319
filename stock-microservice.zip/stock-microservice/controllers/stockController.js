const axios = require('axios');
const client = require('../config/redis');
const STOCK_API = process.env.STOCK_API || 'http://20.244.56.144/evaluation-service';

const getAveragePrice = async (req, res) => {
  try {
    const { ticker } = req.params;
    const minutes = parseInt(req.query.minutes) || 60;
    const now = new Date();
    const timeThreshold = new Date(now.getTime() - minutes * 60000);

    const cacheKey = `stock:${ticker}:${minutes}`;
    const cachedData = await client.get(cacheKey);
    
    if (cachedData) {
      return res.json(JSON.parse(cachedData));
    }

    const response = await axios.get(`${STOCK_API}/stocks/${ticker}?minutes=${minutes}`);
    const priceData = Array.isArray(response.data) ? response.data : [response.data.stock];
    
    const sum = priceData.reduce((acc, item) => acc + item.price, 0);
    const average = sum / priceData.length;

    const result = {
      averageStockPrice: average,
      priceHistory: priceData
    };

    await client.setEx(cacheKey, 60, JSON.stringify(result));

    res.json(result);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to fetch stock data' });
  }
};

module.exports = { getAveragePrice };