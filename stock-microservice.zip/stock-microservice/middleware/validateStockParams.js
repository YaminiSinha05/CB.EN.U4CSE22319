const validateStockParams = (req, res, next) => {
  const { ticker } = req.params;
  const { minutes } = req.query;
  
  if (!ticker) {
    return res.status(400).json({ error: 'Ticker is required' });
  }
  
  if (minutes && isNaN(parseInt(minutes))) {
    return res.status(400).json({ error: 'Minutes must be a number' });
  }
  
  next();
};

module.exports = validateStockParams;