const errorHandler = (err, req, res, next) => {
    console.error('[Error Handler]', err.stack);
    
    const status = err.status || 500;
    const message = err.message || 'Something went wrong!';
    
    if (err.name === 'ValidationError') {
      return res.status(400).json({
        error: 'Validation Error',
        details: err.message,
        fields: err.errors
      });
    }
    
    if (err.code === 'ECONNREFUSED') {
      return res.status(503).json({
        error: 'Service Unavailable',
        message: 'Could not connect to required services'
      });
    }
    
    res.status(status).json({
      error: message,
      stack: process.env.NODE_ENV === 'development' ? err.stack : undefined
    });
  };
  
  module.exports = errorHandler;