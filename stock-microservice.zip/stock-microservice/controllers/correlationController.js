const axios = require('axios');
const client = require('../config/redis');
const STOCK_API = process.env.STOCK_API || 'http://20.244.56.144/evaluation-service';

const calculateAverage = (prices) => {
  return prices.reduce((sum, item) => sum + item.price, 0) / prices.length;
};

const calculateCorrelation = (prices1, prices2) => {
  const pairedData = [];
  const priceMap1 = new Map(prices1.map(item => [item.lastUpdatedAt, item.price]));
  const priceMap2 = new Map(prices2.map(item => [item.lastUpdatedAt, item.price]));

  const commonTimestamps = [...new Set([
    ...prices1.map(item => item.lastUpdatedAt),
    ...prices2.map(item => item.lastUpdatedAt)
  ])].sort();

  for (const timestamp of commonTimestamps) {
    if (priceMap1.has(timestamp) && priceMap2.has(timestamp)) {
      pairedData.push({
        price1: priceMap1.get(timestamp),
        price2: priceMap2.get(timestamp)
      });
    }
  }

  if (pairedData.length < 2) {
    return null; 
  }

  const mean1 = pairedData.reduce((sum, item) => sum + item.price1, 0) / pairedData.length;
  const mean2 = pairedData.reduce((sum, item) => sum + item.price2, 0) / pairedData.length;

  let covariance = 0;
  let variance1 = 0;
  let variance2 = 0;

  for (const item of pairedData) {
    const diff1 = item.price1 - mean1;
    const diff2 = item.price2 - mean2;
    
    covariance += diff1 * diff2;
    variance1 += diff1 * diff1;
    variance2 += diff2 * diff2;
  }

  const correlation = covariance / Math.sqrt(variance1 * variance2);

  return isNaN(correlation) ? null : correlation;
};

const getCorrelation = async (req, res) => {
  try {
    const { minutes, ticker } = req.query;
    const tickers = Array.isArray(ticker) ? ticker : [ticker];
    
    if (!tickers || tickers.length !== 2) {
      return res.status(400).json({ error: 'Exactly two tickers required' });
    }

    const [ticker1, ticker2] = tickers;
    const cacheKey = `correlation:${ticker1}:${ticker2}:${minutes}`;
    
    const cachedData = await client.get(cacheKey);
    if (cachedData) {
      return res.json(JSON.parse(cachedData));
    }

    const [stock1, stock2] = await Promise.all([
      axios.get(`${STOCK_API}/stocks/${ticker1}?minutes=${minutes}`),
      axios.get(`${STOCK_API}/stocks/${ticker2}?minutes=${minutes}`)
    ]);

    const prices1 = Array.isArray(stock1.data) ? stock1.data : [stock1.data.stock];
    const prices2 = Array.isArray(stock2.data) ? stock2.data : [stock2.data.stock];

    const correlation = calculateCorrelation(prices1, prices2);

    if (correlation === null) {
      return res.status(400).json({ 
        error: 'Insufficient overlapping data points to calculate correlation' 
      });
    }

    const result = {
      correlation: parseFloat(correlation.toFixed(4)),
      stocks: {
        [ticker1]: {
          averagePrice: calculateAverage(prices1),
          priceHistory: prices1
        },
        [ticker2]: {
          averagePrice: calculateAverage(prices2),
          priceHistory: prices2
        }
      }
    };

    await client.setEx(cacheKey, 300, JSON.stringify(result));

    res.json(result);
  } catch (error) {
    console.error('Correlation calculation error:', error);
    res.status(500).json({ 
      error: 'Failed to calculate correlation',
      details: error.response?.data || error.message 
    });
  }
};

module.exports = { getCorrelation };