const express = require('express');
const router = express.Router();
const { getAveragePrice } = require('../controllers/stockController');

router.get('/:ticker', getAveragePrice);

module.exports = router;